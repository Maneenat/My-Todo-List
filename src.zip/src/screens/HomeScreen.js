import React, { useState, useEffect } from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet, TextInput } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const STORAGE_KEY = '@todo_tasks';

const HomeScreen = ({ navigation }) => {
  const [tasks, setTasks] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [newTaskTitle, setNewTaskTitle] = useState('');
  const [newTaskCategory, setNewTaskCategory] = useState('');

  const categories = ['All', 'Work', 'Personal', 'Shopping', 'Health'];

  // Load tasks from AsyncStorage when component mounts
  useEffect(() => {
    loadTasks();
  }, []);

  // Save tasks to AsyncStorage whenever they change
  useEffect(() => {
    saveTasks();
  }, [tasks]);

  const loadTasks = async () => {
    try {
      const storedTasks = await AsyncStorage.getItem(STORAGE_KEY);
      if (storedTasks) {
        setTasks(JSON.parse(storedTasks));
      }
    } catch (error) {
      console.error('Error loading tasks:', error);
    }
  };

  const saveTasks = async () => {
    try {
      await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(tasks));
    } catch (error) {
      console.error('Error saving tasks:', error);
    }
  };

  const toggleTask = (id) => {
    setTasks(tasks.map(task =>
      task.id === id ? { ...task, completed: !task.completed } : task
    ));
  };

  const addTask = () => {
    if (newTaskTitle.trim() && newTaskCategory) {
      const newTask = {
        id: Date.now().toString(),
        title: newTaskTitle.trim(),
        category: newTaskCategory,
        completed: false,
        priority: 'Medium',
        notes: '',
        dueDate: null,
      };
      setTasks([...tasks, newTask]);
      setNewTaskTitle('');
      setNewTaskCategory('');
    }
  };

  const updateTask = (updatedTask) => {
    setTasks(tasks.map(task =>
      task.id === updatedTask.id ? updatedTask : task
    ));
  };

  const deleteTask = (id) => {
    setTasks(tasks.filter(task => task.id !== id));
  };

  const filteredTasks = selectedCategory === 'All' 
    ? tasks 
    : tasks.filter(task => task.category === selectedCategory);

  const renderItem = ({ item }) => (
    <TouchableOpacity
      style={styles.taskItem}
      onPress={() => navigation.navigate('TaskDetails', {
        task: item,
        onUpdateTask: updateTask,
        onDeleteTask: deleteTask
      })}
    >
      <View style={styles.taskContent}>
        <TouchableOpacity
          style={[styles.checkbox, item.completed && styles.checkboxCompleted]}
          onPress={() => toggleTask(item.id)}
        >
          {item.completed && <Text style={styles.checkmark}>✓</Text>}
        </TouchableOpacity>
        <View style={styles.taskInfo}>
          <Text style={[
            styles.taskTitle,
            item.completed && styles.completedTask
          ]}>
            {item.title}
          </Text>
          <View style={styles.taskMeta}>
            <Text style={styles.taskCategory}>{item.category}</Text>
            {item.priority && (
              <Text style={[
                styles.taskPriority,
                { color: getPriorityColor(item.priority) }
              ]}>
                {item.priority}
              </Text>
            )}
          </View>
        </View>
      </View>
    </TouchableOpacity>
  );

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'High':
        return '#FF3B30';
      case 'Medium':
        return '#FF9500';
      case 'Low':
        return '#34C759';
      default:
        return '#666';
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.header}>My Todo List</Text>
      
      {/* Category Filter */}
      <View style={styles.categoryContainer}>
        <FlatList
          horizontal
          data={categories}
          renderItem={({ item }) => (
            <TouchableOpacity
              style={[
                styles.categoryButton,
                selectedCategory === item && styles.selectedCategory
              ]}
              onPress={() => setSelectedCategory(item)}
            >
              <Text style={[
                styles.categoryText,
                selectedCategory === item && styles.selectedCategoryText
              ]}>
                {item}
              </Text>
            </TouchableOpacity>
          )}
          keyExtractor={item => item}
          showsHorizontalScrollIndicator={false}
        />
      </View>

      {/* Add Task Form */}
      <View style={styles.addTaskContainer}>
        <TextInput
          style={styles.input}
          placeholder="Enter task title"
          value={newTaskTitle}
          onChangeText={setNewTaskTitle}
        />
        <View style={styles.categoryPicker}>
          {categories.filter(cat => cat !== 'All').map(category => (
            <TouchableOpacity
              key={category}
              style={[
                styles.categoryOption,
                newTaskCategory === category && styles.selectedCategoryOption
              ]}
              onPress={() => setNewTaskCategory(category)}
            >
              <Text style={[
                styles.categoryOptionText,
                newTaskCategory === category && styles.selectedCategoryOptionText
              ]}>
                {category}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
        <TouchableOpacity
          style={styles.addButton}
          onPress={addTask}
        >
          <Text style={styles.addButtonText}>Add Task</Text>
        </TouchableOpacity>
      </View>

      {/* Task List */}
      <FlatList
        data={filteredTasks}
        renderItem={renderItem}
        keyExtractor={item => item.id}
        style={styles.list}
      />

      {/* Summary Button */}
      <TouchableOpacity
        style={styles.summaryButton}
        onPress={() => navigation.navigate('Summary', { tasks })}
      >
        <Text style={styles.summaryButtonText}>View Summary</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#FFF0F5', // Light pink background
  },
  header: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
    color: '#FF69B4', // Hot pink
  },
  categoryContainer: {
    marginBottom: 20,
  },
  categoryButton: {
    paddingHorizontal: 15,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: '#FFB6C1', // Light pink
    marginRight: 10,
  },
  selectedCategory: {
    backgroundColor: '#FF69B4', // Hot pink
  },
  categoryText: {
    color: '#666',
  },
  selectedCategoryText: {
    color: 'white',
  },
  addTaskContainer: {
    backgroundColor: 'white',
    padding: 15,
    borderRadius: 10,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  input: {
    borderWidth: 1,
    borderColor: '#FFB6C1', // Light pink
    borderRadius: 5,
    padding: 10,
    marginBottom: 10,
  },
  categoryPicker: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginBottom: 10,
  },
  categoryOption: {
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 15,
    backgroundColor: '#FFB6C1', // Light pink
    marginRight: 10,
    marginBottom: 10,
  },
  selectedCategoryOption: {
    backgroundColor: '#FF69B4', // Hot pink
  },
  categoryOptionText: {
    color: '#666',
  },
  selectedCategoryOptionText: {
    color: 'white',
  },
  addButton: {
    backgroundColor: '#FF69B4', // Hot pink
    padding: 10,
    borderRadius: 5,
    alignItems: 'center',
  },
  addButtonText: {
    color: 'white',
    fontWeight: 'bold',
  },
  list: {
    flex: 1,
  },
  taskItem: {
    backgroundColor: 'white',
    padding: 15,
    borderRadius: 10,
    marginBottom: 10,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  taskContent: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
  },
  checkbox: {
    width: 24,
    height: 24,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: '#FF69B4', // Hot pink
    marginRight: 10,
    alignItems: 'center',
    justifyContent: 'center',
  },
  checkboxCompleted: {
    backgroundColor: '#FF69B4', // Hot pink
  },
  checkmark: {
    color: 'white',
    fontSize: 16,
  },
  taskInfo: {
    flex: 1,
  },
  taskTitle: {
    fontSize: 16,
    marginBottom: 4,
  },
  taskCategory: {
    fontSize: 12,
    color: '#FF69B4', // Hot pink
  },
  completedTask: {
    textDecorationLine: 'line-through',
    color: '#888',
  },
  taskMeta: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  taskPriority: {
    fontSize: 12,
    marginLeft: 10,
    fontWeight: 'bold',
  },
  summaryButton: {
    backgroundColor: '#FF69B4', // Hot pink
    padding: 15,
    borderRadius: 10,
    marginTop: 20,
  },
  summaryButtonText: {
    color: 'white',
    textAlign: 'center',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default HomeScreen; 