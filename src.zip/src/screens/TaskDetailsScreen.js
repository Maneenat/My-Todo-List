import React, { useState } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  TouchableOpacity, 
  TextInput,
  ScrollView,
  Alert
} from 'react-native';

const TaskDetailsScreen = ({ route, navigation }) => {
  const { task, onUpdateTask, onDeleteTask } = route.params;
  const [editedTask, setEditedTask] = useState({ ...task });
  const [isEditing, setIsEditing] = useState(false);

  const priorities = ['Low', 'Medium', 'High'];
  const categories = ['Work', 'Personal', 'Shopping', 'Health'];

  const handleSave = () => {
    if (editedTask.title.trim() === '') {
      Alert.alert('Error', 'Task title cannot be empty');
      return;
    }
    onUpdateTask(editedTask);
    setIsEditing(false);
  };

  const handleDelete = () => {
    Alert.alert(
      'Delete Task',
      'Are you sure you want to delete this task?',
      [
        {
          text: 'Cancel',
          style: 'cancel'
        },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: () => {
            onDeleteTask(task.id);
            navigation.goBack();
          }
        }
      ]
    );
  };

  const renderPriorityButton = (priority) => (
    <TouchableOpacity
      style={[
        styles.priorityButton,
        editedTask.priority === priority && styles.selectedPriority
      ]}
      onPress={() => setEditedTask({ ...editedTask, priority })}
    >
      <Text style={[
        styles.priorityText,
        editedTask.priority === priority && styles.selectedPriorityText
      ]}>
        {priority}
      </Text>
    </TouchableOpacity>
  );

  const renderCategoryButton = (category) => (
    <TouchableOpacity
      style={[
        styles.categoryButton,
        editedTask.category === category && styles.selectedCategory
      ]}
      onPress={() => setEditedTask({ ...editedTask, category })}
    >
      <Text style={[
        styles.categoryText,
        editedTask.category === category && styles.selectedCategoryText
      ]}>
        {category}
      </Text>
    </TouchableOpacity>
  );

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Task Details</Text>
        <TouchableOpacity
          style={styles.editButton}
          onPress={() => setIsEditing(!isEditing)}
        >
          <Text style={styles.editButtonText}>
            {isEditing ? 'Cancel' : 'Edit'}
          </Text>
        </TouchableOpacity>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Task Title</Text>
        {isEditing ? (
          <TextInput
            style={styles.input}
            value={editedTask.title}
            onChangeText={(text) => setEditedTask({ ...editedTask, title: text })}
            placeholder="Enter task title"
          />
        ) : (
          <Text style={styles.taskTitle}>{task.title}</Text>
        )}
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Category</Text>
        <View style={styles.categoryContainer}>
          {categories.map(category => renderCategoryButton(category))}
        </View>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Priority</Text>
        <View style={styles.priorityContainer}>
          {priorities.map(priority => renderPriorityButton(priority))}
        </View>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Due Date</Text>
        <TouchableOpacity
          style={styles.dateButton}
          onPress={() => {
            // Here you would typically show a date picker
            // For now, we'll just toggle the date
            setEditedTask({
              ...editedTask,
              dueDate: editedTask.dueDate ? null : new Date().toISOString()
            });
          }}
        >
          <Text style={styles.dateText}>
            {editedTask.dueDate 
              ? new Date(editedTask.dueDate).toLocaleDateString()
              : 'Set Due Date'}
          </Text>
        </TouchableOpacity>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Notes</Text>
        <TextInput
          style={styles.notesInput}
          value={editedTask.notes || ''}
          onChangeText={(text) => setEditedTask({ ...editedTask, notes: text })}
          placeholder="Add notes..."
          multiline
          numberOfLines={4}
        />
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Status</Text>
        <TouchableOpacity
          style={[
            styles.statusButton,
            editedTask.completed && styles.completedStatus
          ]}
          onPress={() => setEditedTask({
            ...editedTask,
            completed: !editedTask.completed
          })}
        >
          <Text style={styles.statusText}>
            {editedTask.completed ? 'Completed' : 'Pending'}
          </Text>
        </TouchableOpacity>
      </View>

      {isEditing && (
        <View style={styles.buttonContainer}>
          <TouchableOpacity
            style={[styles.button, styles.saveButton]}
            onPress={handleSave}
          >
            <Text style={styles.buttonText}>Save Changes</Text>
          </TouchableOpacity>
        </View>
      )}

      <TouchableOpacity
        style={[styles.button, styles.deleteButton]}
        onPress={handleDelete}
      >
        <Text style={styles.buttonText}>Delete Task</Text>
      </TouchableOpacity>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFF0F5',
    padding: 20,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#FF69B4',
  },
  editButton: {
    padding: 10,
  },
  editButtonText: {
    color: '#FF69B4',
    fontSize: 16,
  },
  section: {
    backgroundColor: 'white',
    padding: 15,
    borderRadius: 10,
    marginBottom: 15,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 10,
    color: '#FF69B4',
  },
  input: {
    borderWidth: 1,
    borderColor: '#FFB6C1',
    borderRadius: 5,
    padding: 10,
    fontSize: 16,
  },
  taskTitle: {
    fontSize: 18,
    color: '#333',
  },
  categoryContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  categoryButton: {
    paddingHorizontal: 15,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: '#FFB6C1',
    marginRight: 10,
    marginBottom: 10,
  },
  selectedCategory: {
    backgroundColor: '#FF69B4',
  },
  categoryText: {
    color: '#666',
  },
  selectedCategoryText: {
    color: 'white',
  },
  priorityContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  priorityButton: {
    flex: 1,
    padding: 10,
    borderRadius: 5,
    backgroundColor: '#FFB6C1',
    marginHorizontal: 5,
    alignItems: 'center',
  },
  selectedPriority: {
    backgroundColor: '#FF69B4',
  },
  priorityText: {
    color: '#666',
  },
  selectedPriorityText: {
    color: 'white',
  },
  dateButton: {
    padding: 10,
    backgroundColor: '#FFB6C1',
    borderRadius: 5,
    alignItems: 'center',
  },
  dateText: {
    color: '#666',
  },
  notesInput: {
    borderWidth: 1,
    borderColor: '#FFB6C1',
    borderRadius: 5,
    padding: 10,
    height: 100,
    textAlignVertical: 'top',
  },
  statusButton: {
    padding: 10,
    backgroundColor: '#FFB6C1',
    borderRadius: 5,
    alignItems: 'center',
  },
  completedStatus: {
    backgroundColor: '#FF69B4',
  },
  statusText: {
    color: '#666',
  },
  buttonContainer: {
    marginBottom: 15,
  },
  button: {
    padding: 15,
    borderRadius: 10,
    alignItems: 'center',
    marginBottom: 10,
  },
  saveButton: {
    backgroundColor: '#FF69B4',
  },
  deleteButton: {
    backgroundColor: '#FF1493',
  },
  buttonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default TaskDetailsScreen; 